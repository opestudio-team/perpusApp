<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

class Download extends CI_Controller{

  function __construct(){
    parent::__construct();     
    $this->ci =& get_instance();
  }

  function index(){ 
    $key = rawurldecode($this->input->get('d',TRUE));
    if(isset($key)){
        $filename = $this->ci->routines->removeDash($key);
        $filename = $this->ci->routines->ucname($filename);
        $data['filename'] = $filename;
        $this->load->view('page/download_view',$data);
    } else {
        $this->load->view('page/download_error_view');
    }
  }

  function downRequest(){
    $emailTemplate = "Download";
    $email = $this->input->post('emailDownload'); 
    $name = $this->input->post('nama');
    if(isset($email)){ 
        $sending = $this->routines->emailSend($email,$name,$emailTemplate);
        $resSending = json_decode($sending,TRUE);
	$sendCode = $resSending['result_code'];
        
        if($sendCode == 3){
            echo $sendCode;
        } else {
            echo $sendCode;
        }
    }
  }
}
?>