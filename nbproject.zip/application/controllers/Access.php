<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

class Access extends CI_Controller{

  function __construct(){
    parent::__construct();      
  }

  function index(){ 
    $this->load->view('login_view');
  }

  function doLogin(){
    $username = $this->input->post('username');
    $password = $this->input->post('password');

    echo "Username: ".$username." - Password: ".$password;
  }
}
?>