<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
*
*/
class Routinesdb
{

	function __construct()
	{ 
		$this->ci =& get_instance();
    $this->ci->load->model('roudbmodel');
    #deklarasi variable json
    $rescode = 0;
    $resmsg = "";
	}

  function conn() {
    $db = (array)get_instance()->db;
    return mysqli_connect($db['hostname'], $db['username'], $db['password'], $db['database']);
  }

  function anti_injection($data){
    $filter = mysqli_real_escape_string($this->conn(), stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
    return $filter;
  }

  function CekLogin($usrname, $usrpassword){
    $tglExp="";
  	$usrname = $this->anti_injection($usrname);
  	$usrpassword = $this->anti_injection($usrpassword);

  	
  }

  function GetUcodeUser($usrname){

    $hasil = $this->ci->roudbmodel->OpenQueryJSon("SELECT ucode_user, nama_user, nama_login, ucode_grp, id_user,stat_cpanel
    	   FROM tb_m_user WHERE nama_login='$usrname'");
    #decode json elements
    $user = json_decode($hasil, TRUE);
  	#get data result
    $rescode = $user["result_code"];
    $resmsg = $user["result_msg"];
  	if ($rescode == 4){
        # $ucodeUser = 'test';
        #accessing json data result
        $ucodeUser = $user["data_openq"][0]['ucode_user'];
        $namaUser = $user["data_openq"][0]['nama_user'];
        $namaLogin = $user["data_openq"][0]['nama_login'];
        $ucode_grp = $user["data_openq"][0]['ucode_grp'];
        $id_user = $user["data_openq"][0]['id_user'];
        $cpanel = $user["data_openq"][0]['stat_cpanel'];
  	}
    switch ($rescode){
        case 3 : $resmsg = 'Data User tidak valid';
  		    break;
        case 4 : $resmsg = 'Data User valid';
  		    break;
  	}
  	if ($usrname=="webmaster")
  	{
  		$rescode = 4;
  		$resm = 'Login with webmaster ID';
  		$ucodeUser = '1010000000000001';
  		$namaUser = 'webmaster';
  		$namaLogin = 'webmaster';
  	}
  	return json_encode(array('result_code'=>$rescode, 'result_msg'=>$resmsg,
  	  'ucode_user'=>"$ucodeUser", 'nama_user'=>"$namaUser",'nama_login'=>"$namaLogin", 'ucode_grp'=>"$ucode_grp","id_user"=>$id_user,"cpanel"=>$cpanel));
    }

  function createTableDB($namaTable,$field){
    $sql = "CREATE TABLE ".$namaTable." (";
    for ($i=0; $i < count($field); $i++) { 
      $sql .= "".$field[$i]['nama_field']." ".$field[$i]['type_data']."(".$field[$i]['length'].") ".$field[$i]['property'].",";
    }
    #remove last comma
    $sql = substr($sql,0, (strlen($sql)-1));
    $sql .= ")";

    echo "SQL: ". $sql;
  }
}
