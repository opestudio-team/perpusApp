<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//define('uid', "hondaks", true);
define('key', "opeganteng", true);
define('CompanyName', "Ope Studio", true);
define('project',"opestudio", true); 

$config['acts'] = 'opestudio';
